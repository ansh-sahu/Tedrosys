
const LocationReducer = (state, action) => {

  switch (action.type) {
    case "Location":
      localStorage.setItem("Location", JSON.stringify({
        lng: action.payload.longitude,
        lat: action.payload.latitude,
      }));
      return {
        ...state,
        lng: action.payload.longitude,
        lat: action.payload.latitude,
      };
    default:
      return state;
  }
};

export default LocationReducer;