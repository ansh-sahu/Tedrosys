import Category from "../Category";
export default{
    path:"/category",
    element :<Category/>
}