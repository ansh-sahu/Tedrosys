import PersionalLoan from '../Pages/persionalLoan'
export default {
    path:"/persionalLoan",
    element:<PersionalLoan/>
}