import Mobile_number from "../Pages/Mobile_number";
export default {
    path :'/loginNumber',
    element :<Mobile_number/>,
}