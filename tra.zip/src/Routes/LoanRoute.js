import Loan from "../Pages/MainPages/Loan";
export default{
    path:"/loan",
    element: <Loan/>
}