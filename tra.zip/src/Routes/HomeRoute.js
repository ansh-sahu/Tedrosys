import Home from "../Pages/MainPages/Home";

export default {
  path: "/",
  element: <Home />,
};
