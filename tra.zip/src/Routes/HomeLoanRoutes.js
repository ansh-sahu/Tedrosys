import HomeLoan from '../Pages/HomeLoan'
export default {
    path:"/homeLoan",
    element:<HomeLoan/>
}