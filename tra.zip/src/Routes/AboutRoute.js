import About from "../Pages/MainPages/AboutUs";
export default {
    path: "/about",
    element: <About />,
  };
