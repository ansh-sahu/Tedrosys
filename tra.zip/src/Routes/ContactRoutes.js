import ContactUs from "../Pages/MainPages/ContactUs";
export default {
    path:"/contact",
    element:<ContactUs/>
}