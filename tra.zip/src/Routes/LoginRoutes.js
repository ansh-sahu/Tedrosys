import Login from "../Pages/Login";
export default {
    path : "/login",
    element:<Login/>
}