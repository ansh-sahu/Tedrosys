import BussinessLoan from '../Pages/BussinessLoan'
export default {
    path:"/BussinessLoan",
    element:<BussinessLoan/>
}