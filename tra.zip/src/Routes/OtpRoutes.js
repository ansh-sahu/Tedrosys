import Otp from "../Pages/Otp"
export default {
    path:"/otp",
    element:<Otp/>
}