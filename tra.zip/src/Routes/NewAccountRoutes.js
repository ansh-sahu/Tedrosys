import NewAccount from "../Pages/NewAccount";
export default{
    path:"/newAccount",
    element: <NewAccount/>
}