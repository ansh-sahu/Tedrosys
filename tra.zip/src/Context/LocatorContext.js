import { createContext, useContext, useReducer } from "react";
import LocationReducer from "../Reducer/LoacatorReducer";
const LocationContext = createContext();

const initialState = {
  lng: null,
  lat: null
};
const LocationProvider = ({ children }) => {
  const [state, dispatch] = useReducer(LocationReducer, initialState);
  const assignLocation = async (value) => {
    dispatch({
      type: "Location",
      payload: value,
    });
  };

  // console.log(Location);
  return (
    <LocationContext.Provider value={{ location: state, assignLocation }}>
      {children}
    </LocationContext.Provider>
  );
};
const useLocationContext = () => {
  return useContext(LocationContext);
};
export { LocationProvider, LocationContext, useLocationContext };
