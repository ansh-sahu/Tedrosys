import React from 'react';
import "../Css/Home.css";
import listCategor from '../img/List of category/companises.png';
import listCategor1 from '../img/List of category/construction.png';
import listCategor2 from '../img/List of category/technology.png';
import listCategor3 from '../img/List of category/Start-up.png';
import gif from '../img/Service type gif/biggest-Information-Technology-Firm.gif'
const categories = () => {
  return (
    <></>
    // <div className='desktop'>
    //       <section className="category">
    //       <div className="container text-center">
    //         <div className="row">
    //           <div className="col-sm-3 ">
    //             <h3 className="service-type ">Category</h3>
    //             <div className="category-l">
    //               <div className="list">
    //                 <img src={listCategor} alt />
    //                 <a href="Company.html">Companies...</a>
    //               </div>
    //               <hr />
    //               <div className="list">
    //                 <img src={listCategor}  alt />
    //                 <a href="Construction.html">Construction...</a>
    //               </div>
    //               <hr />
    //               <div className="list">
    //                 <img src={listCategor}  alt />
    //                 <a href="Technologies.html">Technologies...</a>
    //               </div>
    //               <hr />
    //               <div className="list">
    //                 <img src={listCategor}  alt />
    //                 <a href="Startup.html">Start-up...</a>
    //               </div>
    //               <hr />
    //               <div className="list">
    //                 <img src={listCategor}  alt />
    //                 <a href="Shop&store.html">Shop &amp; Store...</a>
    //               </div>
    //               <hr />
    //               <div className="list">
    //                 <img src={listCategor} alt />
    //                 <a href="Transport.html">Transport &amp;...</a>
    //               </div>
    //               <hr />
    //               <div className="list">
    //                 <img src={listCategor} alt />
    //                 <a href="Education.html">Education...</a>
    //               </div>
    //               <hr />
    //               <div className="list">
    //                 <img src={listCategor}  alt />
    //                 <a href="other.html">Other...</a>
    //               </div>
    //             </div>
    //             {/* Level 1: .col-sm-3 */}
    //           </div>
    //           <div className="col-sm-9">
    //             {/* service-type section */}
    //             <h3 className="service-type">Service Type</h3>
    //             <div className="row row-cols-1 row-cols-md-2 g-4">
    //               <div className="col">
    //                 <div className="card">
    //                   <img
    //                     src={gif}
    //                     className="card-img-top"
    //                     alt="..."
    //                   />
    //                   <div className="card-body">
    //                     <h5 className="card-title">
    //                       {" "}
    //                       <a href="Company.html" style={{ color: "black" }}>
    //                         Companies
    //                       </a>{" "}
    //                     </h5>
    //                   </div>
    //                 </div>
    //               </div>
    //               <div className="col">
    //                 <div className="card">
    //                   <img
    //                     src={gif}
    //                     className="card-img-top"
    //                     alt="..."
    //                   />
    //                   <div className="card-body">
    //                     <h5 className="card-title">
    //                       <a
    //                         href="Construction.html"
    //                         style={{ color: "black" }}
    //                       >
    //                         Construction
    //                       </a>{" "}
    //                     </h5>
    //                   </div>
    //                 </div>
    //               </div>
    //               <div className="col">
    //                 <div className="card">
    //                   <img
    //                     src={gif}
    //                     className="card-img-top"
    //                     alt="..."
    //                   />
    //                   <div className="card-body">
    //                     <h5 className="card-title">
    //                       <a href="Education.html" style={{ color: "black" }}>
    //                         Education
    //                       </a>{" "}
    //                     </h5>
    //                   </div>
    //                 </div>
    //               </div>
    //               <div className="col">
    //                 <div className="card">
    //                   <img
    //                     src={gif}
    //                     className="card-img-top"
    //                     alt="..."
    //                   />
    //                   <div className="card-body">
    //                     <h5 className="card-title">
    //                       <a href="Shop&store.html" style={{ color: "black" }}>
    //                         Shop &amp; Store
    //                       </a>
    //                     </h5>
    //                   </div>
    //                 </div>
    //               </div>
    //             </div>
    //           </div>
    //         </div>
    //       </div>
    //     </section>
    // </div>
  )
}

export default categories
